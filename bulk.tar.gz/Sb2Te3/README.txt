This directory contains the input files for a VASP calculation created by AutoVASP
The date and time of creation is 2023-01-05 19:04:26.881608 
The structure is Sb2Te3
The space group is R-3m
The lattice parameters are (4.303917965547451, 4.303917965547451, 31.777415302749848) and angles are (90.0, 90.0, 119.99999999999999)
