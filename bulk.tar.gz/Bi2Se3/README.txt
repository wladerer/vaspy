This directory contains the input files for a VASP calculation created by AutoVASP
The date and time of creation is 2023-01-05 19:04:26.868067 
The structure is Bi2Se3
The space group is R-3m
The lattice parameters are (4.191366525881255, 4.191366525881255, 29.92868720220962) and angles are (90.0, 90.0, 119.99999999999999)
