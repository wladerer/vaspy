This directory contains the input files for a VASP calculation created by AutoVASP
The date and time of creation is 2023-01-05 19:04:26.875156 
The structure is Bi2Te3
The space group is R-3m
The lattice parameters are (4.418130446801545, 4.418130446801545, 32.25729903921035) and angles are (90.0, 90.0, 120.00000000000001)
