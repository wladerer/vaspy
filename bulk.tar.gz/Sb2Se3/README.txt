This directory contains the input files for a VASP calculation created by AutoVASP
The date and time of creation is 2023-01-05 19:04:26.878755 
The structure is Sb2Se3
The space group is Pnma
The lattice parameters are (4.00155687, 11.71362971, 12.3620732) and angles are (90.0, 90.0, 90.0)
