This directory contains the input files for a VASP calculation created by AutoVASP
The date and time of creation is 2023-01-05 21:07:08.174761 
The structure is Ti2Ga3
The space group is P4/m
The lattice parameters are (6.2427974108680475, 6.2427974108680475, 3.97643212) and angles are (90.0, 90.0, 90.0)
