This directory contains the input files for a VASP calculation created by AutoVASP
The date and time of creation is 2023-01-05 21:07:08.169797 
The structure is P2W
The space group is Cmc2_1
The lattice parameters are (3.185465801102603, 11.171110252953543, 4.98374023) and angles are (90.0, 90.0, 90.0)
