This directory contains the input files for a VASP calculation created by AutoVASP
The date and time of creation is 2023-01-05 21:07:08.164727 
The structure is B2Mo
The space group is R-3m
The lattice parameters are (3.0148025280845094, 3.0148025280845094, 20.877556938945116) and angles are (90.0, 90.0, 119.99999999999999)
