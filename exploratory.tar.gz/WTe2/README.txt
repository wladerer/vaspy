This directory contains the input files for a VASP calculation created by AutoVASP
The date and time of creation is 2023-01-05 21:07:08.172351 
The structure is Te2W
The space group is Pmn2_1
The lattice parameters are (3.5185995999999995, 6.302336209999999, 15.00577666) and angles are (90.0, 90.0, 90.0)
