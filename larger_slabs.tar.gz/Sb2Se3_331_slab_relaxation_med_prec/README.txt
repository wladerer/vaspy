This directory contains the input files for a VASP calculation created by AutoVASP
The date and time of creation is 2022-12-21 18:22:46.416183 
The structure is Sb2Se3
The space group is Pm
The lattice parameters are (12.08555316755992, 34.62563026067013, 89.8586891276961) and angles are (90.0, 90.0, 90.0)
