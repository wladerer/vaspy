This directory contains the input files for a VASP calculation created by AutoVASP
The date and time of creation is 2022-12-21 18:24:16.840876 
The structure is Bi2Te3
The space group is P-3m1
The lattice parameters are (13.352651980037697, 13.352651980037697, 127.75064246531035) and angles are (90.0, 90.0, 119.99999518331931)
