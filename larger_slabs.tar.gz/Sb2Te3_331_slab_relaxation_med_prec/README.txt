This directory contains the input files for a VASP calculation created by AutoVASP
The date and time of creation is 2022-12-21 18:24:16.859650 
The structure is Sb2Te3
The space group is P-3m1
The lattice parameters are (12.991937984930011, 12.991937984930011, 125.349205135896) and angles are (90.0, 90.0, 119.99999938662512)
