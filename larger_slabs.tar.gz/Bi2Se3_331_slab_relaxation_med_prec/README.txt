This directory contains the input files for a VASP calculation created by AutoVASP
The date and time of creation is 2022-12-21 18:24:16.823414 
The structure is Bi2Se3
The space group is P-3m1
The lattice parameters are (12.57775207547009, 12.577752075470093, 124.69831067467356) and angles are (90.0, 90.0, 120.00000284924681)
